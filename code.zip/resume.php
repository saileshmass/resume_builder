<!DOCTYPE html>
<html lang="en">
    <head>
        <met#aeb3b8et="utf-8">
        <title>Resume</title>
        <meta content="width=device-width, initial-scale=1.0" name="viewport">
      

  

        <!-- Google Web Fonts -->
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@300;400;500;600;700&display=swap" rel="stylesheet">

        <!-- Icon Font Stylesheet -->
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

        <!-- Libraries Stylesheet -->
        <!-- <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
        <link href="lib/lightbox/css/lightbox.min.css" rel="stylesheet"> -->
        <link href="lib/animate/animate.min.css" rel="stylesheet">

        <!-- Customized Bootstrap Stylesheet -->
        <link href="css/bootstrap.min.css" rel="stylesheet">

        <!-- Template Stylesheet -->
        <link href="css/style.css" rel="stylesheet">
        <link href="css/custom.css" rel="stylesheet">
    </head>

    <body>
        <!-- Spinner Start -->
        <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->
        
        <?php
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $name = $_POST["name"];
            $email = $_POST["email"];
            $phone = $_POST["phone"];
            $object = $_POST["object"];
            $role = $_POST["role"];
            $birth = $_POST["dob"];
            $experience = $_POST["exp"];
         
            // Upload image
            if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
                $uploadDir = 'uploads/';
                $uploadFile = $uploadDir . basename($_FILES['image']['name']);
                if (move_uploaded_file($_FILES['image']['tmp_name'], $uploadFile)) {
                    // echo '<p><strong>Uploaded Image:</strong></p>';
                    // echo '<img src="' . $uploadFile . '" alt="Uploaded Image">';
                } else {
                    echo 'Image upload failed.';
                }
            }
        }
        ?>
      

      <!-- COntainer Start -->
        <div class="container">


            <div class="row g-5">
                <div class="col-lg-4 sticky-lg-top vh-100">
                    <div class="d-flex flex-column h-100 text-center overflow-auto shadow">

                            <div>
                        
                                <img class="w-100 img-fluid mb-4" src="<?php echo $uploadFile;?>" alt="Image">
                            </div>

                                 <h1 class="text-primary mt-2"><?php echo $name; ?></h1>
                      
                                <div class="mb-4" style="height: 22px;">
                                
                                    <div class="typed-text"><h4><?php echo $role; ?></h4></div>
                                </div>

                                <button  type="button" class="btn btn-primary">BACK</button>
                    
                      
                    </div>
                </div>
                <div class="col-lg-8">
                    <!-- About Start -->
                    <section class="pt-5 border-bottom wow fadeInUp" data-wow-delay="0.1s">
                        <h1 class="title pb-3 mb-5">About Me</h1>
                        <p><?php echo $object; ?></p>
                        <div class="row mb-4">
                            <div class="col-sm-6 py-1">
                                <span class="fw-medium text-primary">Name:</span><?php echo $name; ?></span>
                            </div>
                            <div class="col-sm-6 py-1">
                                <span class="fw-medium text-primary">Mobile Number:</span><?php echo $phone; ?></span>
                            </div>
                            <div class="col-sm-6 py-1">
                                <span class="fw-medium text-primary">DOB:</span> <?php echo $birth; ?></span></span> 
                            </div>
                            <div class="col-sm-6 py-1">
                                <span class="fw-medium text-primary">Experience:</span> <?php echo $experience; ?></span></span> 
                            </div>
                        </div>
                    
                    </section>
                    <!-- About End -->

                    <!-- Experience -->
                    <section class="pt-5 wow fadeInUp" data-wow-delay="0.1s" style="visibility: visible; animation-delay: 0.1s; animation-name: fadeInUp;">
                        <h1 class="title pb-3 mb-5">Expericence</h1>

                        <div class="border-start border-2 border-light pt-2 ps-5">
                                <?php
                                if(isset($_POST['experience_type'])) {
                                    $experience_types = $_POST['experience_type'];
                                    $experience_roles = $_POST['experience_job_role'];
                                    $experience_titles = $_POST['experience_job_title'];

                                    for($i = 0; $i < count($experience_types); $i++) {
                                        echo '<div class="job-details mb-4">';
                                        echo '<p><strong>Job Type:  </strong>'  .$experience_types[$i].'</p>';
                                        echo '<p><strong>Company Name:  </strong>'  .$experience_roles[$i].'</p>';
                                        echo '<p><strong>Job Role:  </strong>'  .$experience_titles[$i].'</p>';
                                        echo '</div>';
                                    }
                                }
                                ?>
                            
                           
                            
                        </div>
                    </section>

                    <!--Experience -->
                    

                  
                    <!-- Skills Start -->
                 

                    <section class="pt-5 border-bottom wow fadeInUp" data-wow-delay="0.1s">
                        <h1 class="title pb-3 mb-5">Skills</h1>
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="form-floating py-1">
                                    <?php
                                    if(isset($_POST['skill_type'])) {
                                        $skill_types = $_POST['skill_type'];
                                        $skill_types_array = explode(',', $skill_types);

                                        foreach ($skill_types_array as $skill_type) {
                                            echo '<p><strong>Skill: </strong>' . trim($skill_type) . '</p>';
                                        }
                                    }
                                    ?>
                                </div>
                            </div>
                        </div>
                    </section>



                <!-- Skills End -->
                    

                <!-- ... Previous HTML content ... -->

                <section class="py-3 border-bottom wow fadeInUp" data-wow-delay="0.1s">
    <h1 class="title pb-3 mb-5">Education Qualification</h1>
    <div class="row">
        <div class="col-sm-12">
            <div class="experience1">
                <?php
                if (isset($_POST['college_name'])) {
                    $college_names = $_POST['college_name'];
                    $course_names = $_POST['course_name'];
                    $course_marks = $_POST['course_mark'];

                    echo '<table class="table">';
                    echo '<thead>';
                    echo '<tr>';
                    echo '<th>College Name</th>';
                    echo '<th>Course Name</th>';
                    echo '<th>CGPA</th>';
                    echo '</tr>';
                    echo '</thead>';
                    echo '<tbody>';

                    for ($i = 0; $i < count($college_names); $i++) {
                        echo '<tr>';
                        echo '<td>' . $college_names[$i] . '</td>';
                        echo '<td>' . $course_names[$i] . '</td>';
                        echo '<td>' . $course_marks[$i] . '</td>';
                        echo '</tr>';
                    }

                    echo '</tbody>';
                    echo '</table>';
                }
                ?>
            </div>
           
        </div>
    </div>
</section>


<!-- ... Rest of the HTML content ... -->

          

               

              

                  
                  

                   


              
                </div>
            </div>
        </div>


        
        <!-- Back to Top -->
        <a href="#" class="back-to-top"><i class="fa fa-angle-double-up"></i></a>
        
        <!-- JavaScript Libraries -->
        <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
        <script src="lib/wow/wow.min.js"></script>
        <script src="lib/typed/typed.min.js"></script>
        <script src="lib/easing/easing.min.js"></script>
        <script src="lib/waypoints/waypoints.min.js"></script>
        <script src="lib/counterup/counterup.min.js"></script>


        <!-- Contact Javascript File -->
        <script src="mail/jqBootstrapValidation.min.js"></script>
        <script src="mail/contact.js"></script>

        <!-- Template Javascript -->
        <script src="js/main.js"></script>

        <script>
             const dropContainer = document.getElementById("dropcontainer")
                    const fileInput = document.getElementById("images")

                    dropContainer.addEventListener("dragover", (e) => {
                        // prevent default to allow drop
                        e.preventDefault()
                    }, false)

                    dropContainer.addEventListener("dragenter", () => {
                        dropContainer.classList.add("drag-active")
                    })

                    dropContainer.addEventListener("dragleave", () => {
                        dropContainer.classList.remove("drag-active")
                    })

                    dropContainer.addEventListener("drop", (e) => {
                        e.preventDefault()
                        dropContainer.classList.remove("drag-active")
                        fileInput.files = e.dataTransfer.files
                    })
        </script>
    </body>
</html>