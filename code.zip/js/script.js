document.addEventListener("DOMContentLoaded", function () {
    const addEducationButton = document.getElementById("add-education");
    const educationContainer = document.querySelector(".education");

    addEducationButton.addEventListener("click", function () {
        const educationItem = document.createElement("div");
        educationItem.classList.add("education-item");
        educationItem.innerHTML = `
            <input type="text" name="education_institution[]" placeholder="Institution Name" required>
            <input type="text" name="education_grade[]" placeholder="Grade" required>
            <input type="text" name="education_marks[]" placeholder="Marks" required>
        `;
        educationContainer.appendChild(educationItem);
    });

    const addProjectButton = document.getElementById("add-project");
    const projectsContainer = document.querySelector(".projects");

    addProjectButton.addEventListener("click", function () {
        const projectItem = document.createElement("div");
        projectItem.classList.add("project-item");
        projectItem.innerHTML = `
            <input type="text" name="project_title[]" placeholder="Project Title" required>
            <textarea name="project_description[]" rows="4" placeholder="Project Description" required></textarea>
        `;
        projectsContainer.appendChild(projectItem);
    });
    const addSkillButton = document.getElementById("add-skills");
    const skillsContainer = document.querySelector(".skills");

    addSkillButton.addEventListener("click", function () {
        const skillItem = document.createElement("div");
        skillItem.classList.add("skill-item");
        skillItem.innerHTML = `
        <input type="text" name="skills[]" required>
        `;
        skillsContainer.appendChild(skillItem);
    });

    const addExperienceButton = document.getElementById("add-experience");
    const experienceContainer = document.querySelector(".experience");

    addExperienceButton.addEventListener("click", function () {
        const experienceItem = document.createElement("div");
        experienceItem.classList.add("experience-item");
        experienceItem.innerHTML = `
            <select name="experience_type[]">
                <option value="Internship">Internship</option>
                <option value="Full-time">Full-time</option>
                <option value="Contractual">Contractual</option>
            </select>
            <input type="text" name="experience_job_role[]" placeholder="Job Role" required>
            <input type="text" name="experience_job_title[]" placeholder="Job Title" required>
        `;
        experienceContainer.appendChild(experienceItem);
    });
});
